from langgraph.graph import StateGraph, END
from agents.research_agent import get_research_agent
from agents.answer_agent import get_answer_agent

def build_flow():
    graph = StateGraph()

    research_tool = get_research_agent()
    answer_agent = get_answer_agent()

    def fetch_data(state):
        results = research_tool.run(state["query"])
        return {"data": results}

    def draft_answer(state):
        return {"answer": answer_agent.run({"data": state["data"]})}

    graph.add_node("FetchData", fetch_data)
    graph.add_node("DraftAnswer", draft_answer)

    graph.set_entry_point("FetchData")
    graph.add_edge("FetchData", "DraftAnswer")
    graph.add_edge("DraftAnswer", END)

    return graph.compile()
