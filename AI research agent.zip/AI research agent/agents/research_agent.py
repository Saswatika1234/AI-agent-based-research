from langchain_community.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

def get_research_agent():
    llm = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0.7)
    prompt = PromptTemplate(
        input_variables=["question"],
        template="Research this question in depth: {question}",
    )
    return LLMChain(llm=llm, prompt=prompt)
