from langchain_community.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

def get_answer_agent():
    llm = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0.7)
    prompt = PromptTemplate(
        input_variables=["data"],
        template="Based on the following research data, write a detailed answer:\n\n{data}"
    )
    return LLMChain(llm=llm, prompt=prompt)