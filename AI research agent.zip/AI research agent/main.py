import os
from dotenv import load_dotenv
from flow.research_flow import build_flow

load_dotenv()

if __name__ == "_main_":
    question = input("Enter your research question: ")
    app = build_flow()
    result = app.invoke({"question": question})
    print("Answer:\n", result["answer"])
